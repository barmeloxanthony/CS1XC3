/**
 * @file course.c
 * @author Paarth Kadakia
 * @brief Defines functions to be used with Course object
 * @version 0.1
 * @date 2022-04-12
 * 
 * @copyright Copyright (c) 2022
 */

#include "course.h"
#include <stdlib.h>
#include <stdio.h>
/**
 * @brief Adds the passed in student object to the passed in course object
 * 
 * @param course a Course that student is enrolling in.
 * @param student a Student object that will be enrolled to the course
 * @return nothing
 */
void enroll_student(Course *course, Student *student)
{
  course->total_students++;
  if (course->total_students == 1) 
  {
    // Space given for only one Student object to be created
    course->students = calloc(1, sizeof(Student));
  }
  else 
  // For an array of students that have been definied, allocates space for each new student.
  {
    course->students = 
      realloc(course->students, course->total_students * sizeof(Student)); 
  }
  course->students[course->total_students - 1] = *student;
}
/**
 * @brief Prints the Course.
 * 
 * @param course a Course object to be printed
 * @return nothing
 */
void print_course(Course* course)
{ // prints attributes from the course
  printf("Name: %s\n", course->name);
  printf("Code: %s\n", course->code);
  printf("Total students: %d\n\n", course->total_students);
  printf("****************************************\n\n");

  // loops through all students in the course and prints their attributes.
  for (int i = 0; i < course->total_students; i++) 
    print_student(&course->students[i]);
}
/**
 * @brief Prints the student with the highest average in the course.
 * 
 * @param course a Course object to identify the highest average student.
 * @return Student* with highest average
 */
Student* top_student(Course* course)
{ // in the case there are no students return NULL.
  if (course->total_students == 0) return NULL;
  //creates variable to store the student average, max average and a pointer to adjust the max average.
  double student_average = 0;
  double max_average = average(&course->students[0]);
  Student *student = &course->students[0];
  // loops through every student in the course. If the next average is higher than the previous store it as the max average.
  for (int i = 1; i < course->total_students; i++)
  {
    student_average = average(&course->students[i]);
    if (student_average > max_average) 
    {
      max_average = student_average;
      student = &course->students[i];
    }   
  }
  // returns student with max average.
  return student;
}
/**
 * @brief returns an array of all students passign in the course and stores the amount of students passing.
 * 
 * @param course a Course object.
 * @param total_passing a pointer that stores how many students are passing.
 * @return Student* is an array of all the students who have passed the course.
 */
Student *passing(Course* course, int *total_passing)
{
  //
  int count = 0;
  Student *passing = NULL;
  // loops through the students in the course to see who's mark is above 50 to add it to the count
  for (int i = 0; i < course->total_students; i++) 
    if (average(&course->students[i]) >= 50) count++;
  // allocates space for each student who has passed for the list that will be created
  passing = calloc(count, sizeof(Student));

  // loops through array of students once more adding them to the array if they passed.
  int j = 0;
  for (int i = 0; i < course->total_students; i++)
  {
    if (average(&course->students[i]) >= 50)
    {
      passing[j] = course->students[i];
      j++; 
    }
  }

  *total_passing = count;

  return passing;
}