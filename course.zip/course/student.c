/**
 * @file student.c
 * @author Paarth Kadakia
 * @brief Defines the functions that involve using a Student object
 * @version 0.1
 * @date 2022-04-12
 * 
 * @copyright Copyright (c) 2022
 * 
 */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "student.h"
/**
 * @brief adds a grade to the given student.
 * 
 * @param student - Student who will be given a grade
 * @param grade - Grade to add to student's grade array.
 */
void add_grade(Student* student, double grade)
{
  student->num_grades++;
  // If this is the first grade that is given allocate space on the heap to store it
  if (student->num_grades == 1) student->grades = calloc(1, sizeof(double));
  // reallocates the memory of the grades list using realloc so it can hold one more double.
  else 
  {
    
    student->grades = 
      realloc(student->grades, sizeof(double) * student->num_grades);
  }
  // Adds a new grade to the student array
  student->grades[student->num_grades - 1] = grade;
}

/**
 * @brief Calculates the student's average
 * 
 * @param student - Student whose average is being calculated.
 * @return double containg the student's average
 */
double average(Student* student)
{
  if (student->num_grades == 0) return 0;

  double total = 0;
  // Loops through grade list and calculates total marks.
  for (int i = 0; i < student->num_grades; i++) total += student->grades[i];
  // Returns average grade of the student.
  return total / ((double) student->num_grades);
}

/**
 * @brief Converts all attributes in student object into a string
 * 
 * @param student - Student to print.
 */
void print_student(Student* student)
{
  // Prints all attributes in student.
  printf("Name: %s %s\n", student->first_name, student->last_name);
  printf("ID: %s\n", student->id);
  printf("Grades: ");
  // Loops through each of the student's grade array and prints its elements.
  for (int i = 0; i < student->num_grades; i++) 
    printf("%.2f ", student->grades[i]);
  printf("\n");
  printf("Average: %.2f\n\n", average(student));
}

/**
 * @brief Creates a random Student 
 * 
 * @param grades - the number of grades to be generated
 * @return Student* 
 */
Student* generate_random_student(int grades)
{
  // Arrays all possible first and last names given.
  char first_names[][24] = 
    {"Shahrzad", "Leonti", "Alexa", "Ricardo", "Clara", "Berinhard", "Denzel",
     "Ali", "Nora", "Malcolm", "Muhammad", "Madhu", "Jaiden", "Helena", "Diana",
     "Julie", "Omar", "Yousef",  "Amir", "Wang", "Li", "Zhang", "Fen", "Lin"};

  char last_names[][24] = 
   {"Chen", "Yang", "Zhao", "Huang", "Brown", "Black", "Smith", "Williams", 
    "Jones", "Miller", "Johnson", "Davis", "Abbas", "Ali", "Bakir", "Ismat", 
    "Khalid", "Wahed", "Taleb", "Hafeez", "Hadid", "Lopez", "Gonzalez", "Moore"};

  // creates a new list on the heap for student object.
  Student *new_student = calloc(1, sizeof(Student));

  // assigning a random first and last name to the randomly generated student.
  strcpy(new_student->first_name, first_names[rand() % 24]);
  strcpy(new_student->last_name, last_names[rand() % 24]);

  // converts the ASCII character to a single digit number. this reapeats ten times to create the student ID. 
  for (int i = 0; i < 10; i++) new_student->id[i] = (char) ((rand() % 10) + 48);
  new_student->id[10] = '\0';

  // Generates random grades with a minimum grade of 25.
  for (int i = 0; i < grades; i++) 
  {
    add_grade(new_student, (double) (25 + (rand() % 75)));
  }

  return new_student;
}