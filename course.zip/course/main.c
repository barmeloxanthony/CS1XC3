/**
 * @file main.c
 * @author Paarth Kadakia
 * @brief Demonstrates the student and course libraries' function
 * @version 0.1
 * @date 2022-04-12
 * 
 * @copyright Copyright (c) 2022
 * 
 */
#include <stdlib.h> 
#include <stdio.h>
#include <string.h>
#include "time.h"
#include "course.h"
/**
 * @brief Demonstartes how the function in the libraries work
 * 
 * @return int 
 */
int main()
{
  // To produce a random number based on computers internal clock.
  srand((unsigned) time(NULL));

  // Creates a Course object calloc() is used to allocate memory and initializes every byte in the allocated memory to 0.
  Course *MATH101 = calloc(1, sizeof(Course));
  strcpy(MATH101->name, "Basics of Mathematics");
  strcpy(MATH101->code, "MATH 101");

  // creates 20 random Student objects who each have 8 grades
  for (int i = 0; i < 20; i++) 
    enroll_student(MATH101, generate_random_student(8));
  
  print_course(MATH101);


  // prints the student with the highest average of the course
  Student *student;
  student = top_student(MATH101);
  printf("\n\nTop student: \n\n");
  print_student(student);

  // function name defines itself. Loops through all stundents in MATH101 and finds whos passing
  int total_passing;
  Student *passing_students = passing(MATH101, &total_passing);
  printf("\nTotal passing: %d\n", total_passing);
  printf("\nPassing students:\n\n");
  for (int i = 0; i < total_passing; i++) print_student(&passing_students[i]);
  
  return 0;
}