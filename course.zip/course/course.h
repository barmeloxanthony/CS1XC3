#include "student.h"
#include <stdbool.h>
/**
 * @file course.h
 * @author Paarth Kadakia
 * @brief A custom library which has the typedef struct of the course.
 * @version 0.1
 * @date 2022-04-12
 * 
 * @copyright Copyright (c) 2022
 * 
 */

/**
 * @brief Struct to represent courses the struct contains the course name, code, array of students and number of students. 
 * @warning  course code cannot exceed 50 characters. Course name cannot exceed 100 characters 
 */
typedef struct _course 
{
  char name[100]; // the title of the course
  char code[10]; //course code 
  Student *students; //array of students in the course 
  int total_students; // number of students in the course 
} Course;

void enroll_student(Course *course, Student *student);
void print_course(Course *course);
Student *top_student(Course* course);
Student *passing(Course* course, int *total_passing);

